<?php

// Kết nối CSDL
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlbanhang";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Lấy thông tin người dùng đang đăng nhập
session_start()
$user = "'.$_POST["email"]'";

// Xử lý form
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Lấy dữ liệu từ form
    $password_old = $_POST["password_old"];
    $password_new = $_POST["password_new"];
    $password_confirm = $_POST["password_confirm"];

    // Kiểm tra mật khẩu cũ
    $sql = "SELECT password FROM customers WHERE email = '$user'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    $password_db = $row["password"];

    if (!password_verify($password_old, $password_db)) {
        $error_message = "Mật khẩu cũ không đúng.";
    }

    // Kiểm tra mật khẩu mới
    if ($password_new != $password_confirm) {
        $error_message = "Mật khẩu mới không khớp.";
    }

    // Nếu không có lỗi
    if (!isset($error_message)) {

        // Băm mật khẩu mới
        $password_new = password_hash($password_new, PASSWORD_DEFAULT);

        // Cập nhật mật khẩu mới vào CSDL
        $sql = "UPDATE customers SET password = '$password_new' WHERE email = '$email'";
        mysqli_query($conn, $sql);

        // Thông báo thành công
        $success_message = "Mật khẩu đã được cập nhật thành công.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Đổi mật khẩu</title>
</head>
<body>

    <?php if (isset($error_message)) { ?>
        <div class="error-message"><?php echo $error_message; ?></div>
    <?php } ?>

    <?php if (isset($success_message)) { ?>
        <div class="success-message"><?php echo $success_message; ?></div>
    <?php } ?>

    <form action="sua_mk.php" method="post">
        <input type="text" name="email" placeholder="ten tai khoan">
        <input type="password" name="password_old" placeholder="Mật khẩu cũ">
        <input type="password" name="password_new" placeholder="Mật khẩu mới">
        <input type="password" name="password_confirm" placeholder="Nhập lại mật khẩu mới">
        <input type="submit" value="Đổi mật khẩu">
    </form>

</body>
</html>